# TopCoder Camera Integration
Show Your Skills Challenge

## Challenge Overview

A picture is sometimes worth 1,000 words.  In the application, allow a user to pull a photo from their photostream or take a new photo of what they are trying to report.  Add this to the symptoms page.  The symptoms page can just be mocked up with a button to add photo.  You are not responsible for the symptom page other than how to transition to the camera and capturing the image or taking a new photo.

This will be developed in iOS 8.


## Notes

- My second Show Your Skills Challenge.  
- Improved my documentation from the first challenge, especially after reviewing other submissions great work.
- Relied more on Xcodes built in tools, with no images added.



## Contribute if you want!

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

## History

TODO: Write history

## Credits

[Creating a Camera Application with Swift](https://youtu.be/GJFHWsbTvR8) on YouTube.

